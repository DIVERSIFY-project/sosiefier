package net.sourceforge.pmd.util.designer;

public interface LineGetter {
    String getLine(int number);
}
