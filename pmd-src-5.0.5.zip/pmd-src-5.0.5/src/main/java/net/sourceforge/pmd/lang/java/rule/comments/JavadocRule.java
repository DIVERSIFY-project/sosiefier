package net.sourceforge.pmd.lang.java.rule.comments;

public class JavadocRule extends AbstractCommentRule {



}
