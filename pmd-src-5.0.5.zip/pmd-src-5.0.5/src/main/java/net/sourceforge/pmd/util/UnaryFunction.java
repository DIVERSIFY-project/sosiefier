/**
 * BSD-style license; for more info see http://pmd.sourceforge.net/license.html
 */
package net.sourceforge.pmd.util;

public interface UnaryFunction<E> {
    void applyTo(E o);
}
