#!/bin/sh

for i in `cat $1`
do
java  -javaagent:../jacocoagent.jar -cp .:target/test-classes/:target/metrics-parent-3.0.0-RC2-SNAPSHOT-jar-with-dependencies.jar:../junit/target/junit-4.12-SNAPSHOT.jar:../junit/lib/hamcrest-core-1.3.jar org.junit.runner.JUnitCore $i
done
