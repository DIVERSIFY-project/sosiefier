package com.codahale.metrics;

/**
 * A tag interface to indicate that a class is a metric.
 */
public interface Metric {

}
